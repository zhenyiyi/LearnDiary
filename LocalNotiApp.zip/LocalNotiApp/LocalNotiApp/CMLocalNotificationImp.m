//
//  CMLocalNotificationImp.m
//  LocalNotiApp
//
//  Created by 张枫林 on 2018/11/23.
//

#import "CMLocalNotificationImp.h"
#import "CMLocalNotificationCenter.h"

@implementation CMLocalNotificationImp

- (void)userNotificationCenter:(UNUserNotificationCenter *)center willPresentNotification:(UNNotification *)notification withCompletionHandler:(void (^)(UNNotificationPresentationOptions options))completionHandler API_AVAILABLE(ios(10.0)){
    NSLog(@"userNotificationCenter notification : %@",notification);
    completionHandler(UNNotificationPresentationOptionAlert | UNNotificationPresentationOptionSound);
    [[CMLocalNotificationCenter defaultCenter] didReceiveLocalNotificationUserInfo:notification.request.content.userInfo];
}

- (void)userNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(UNNotificationResponse *)response withCompletionHandler:(void(^)(void))completionHandler API_AVAILABLE(ios(10.0)){
    NSLog(@"userNotificationCenter response : %@",response);
}
@end
