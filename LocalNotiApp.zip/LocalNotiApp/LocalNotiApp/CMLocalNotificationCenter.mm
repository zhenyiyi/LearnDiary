//
//  CMLocalNotificationImp.h
//  LocalNotiApp
//
//  Created by 张枫林 on 2018/11/23.
//

#import "CMLocalNotificationCenter.h"
#import <Availability.h>
#import "CMLocalNotificationImp.h"


NSString *const CMLocalNotificationHandlingKeyName = @"CMNotiKey";
NSString *const CMApplicationDidReceiveLocalNotification = @"CMApplicationDidReceiveLocalNotification";


@interface CMLocalNotification ()
@property (nonatomic, readwrite, copy) NSString *identifier;
@property (nonatomic, readwrite, copy) NSString *alertBody;
@property (nonatomic, readwrite, copy) NSDictionary *userInfo;
@property (nonatomic, readwrite, copy) NSDate* fireDate;
@property (nonatomic, readwrite, copy) UILocalNotification* localNoti;

@end

@implementation CMLocalNotification

- (instancetype)initWithDictionary:(NSDictionary *)result{
    self = [super init];
    if (self) {
        [self setValuesForKeysWithDictionary:result];
    }
    return self;
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    NSLog(@"%s",__func__);
}

@end

@interface CMLocalNotificationCenter()
@property (nonatomic) NSMutableDictionary* localPushDictionary;
@property (nonatomic) CMLocalNotificationImp* notiImp;
@end

static CMLocalNotificationCenter *defaultCenter;

@implementation CMLocalNotificationCenter

+ (instancetype)defaultCenter{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        defaultCenter = [CMLocalNotificationCenter new];
        defaultCenter.localPushDictionary = [NSMutableDictionary new];
        [defaultCenter loadScheduledLocalPushNotificationsFromApplication];
        defaultCenter.notiImp = [CMLocalNotificationImp new];
        defaultCenter.localNotificationHandler = nil;
    });
    return defaultCenter;
}

- (void)loadScheduledLocalPushNotificationsFromApplication{
    if (@available(iOS 10.0, *)){
        [[UNUserNotificationCenter currentNotificationCenter] getPendingNotificationRequestsWithCompletionHandler:^(NSArray<UNNotificationRequest *> * _Nonnull requests) {
            [requests enumerateObjectsUsingBlock:^(UNNotificationRequest * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                if (obj.identifier && obj.content.userInfo[CMLocalNotificationHandlingKeyName]) {
                    CMLocalNotification * noti = [[CMLocalNotification alloc] initWithDictionary:obj.content.userInfo];
                    [self.localPushDictionary setObject:noti forKey:obj.identifier];
                }
            }];
        }];
    }else{
        NSArray *scheduleLocalPushNotifications = [[UIApplication sharedApplication] scheduledLocalNotifications];
        for (UILocalNotification *localNoti in scheduleLocalPushNotifications) {
            if (localNoti.userInfo[CMLocalNotificationHandlingKeyName]) {
                CMLocalNotification * noti = [[CMLocalNotification alloc] initWithDictionary:localNoti.userInfo];
                noti.localNoti = localNoti;
                [self.localPushDictionary setObject: noti forKey:localNoti.userInfo[CMLocalNotificationHandlingKeyName]];
            }
        }
    }
}

- (void) appRegisterlocalNotifications;{
    UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeAlert | UIUserNotificationTypeBadge | UIUserNotificationTypeSound) categories:nil];
    [[UIApplication sharedApplication] registerUserNotificationSettings:settings];
    if (@available(iOS 10.0, *)) {
        UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
        // 必须写代理，不然无法监听通知的接收与点击
        center.delegate = _notiImp;
        [center requestAuthorizationWithOptions:(UNAuthorizationOptionAlert | UNAuthorizationOptionBadge | UNAuthorizationOptionSound) completionHandler:^(BOOL granted, NSError * _Nullable error) {
            if (granted) {
                [center getNotificationSettingsWithCompletionHandler:^(UNNotificationSettings * _Nonnull settings) {
                    NSLog(@"%@", settings);
                }];
            }
        }];
    }
}

- (NSArray *)localNotifications{
    return [[NSArray alloc] initWithArray:[self.localPushDictionary allValues]];
}

- (void)didReceiveLocalNotificationUserInfo:(NSDictionary *)userInfo{
    NSString *key = userInfo[CMLocalNotificationHandlingKeyName];
    if (!key) {
        return;
    }
    NSLog(@"self.localPushDictionary1: %@",self.localPushDictionary);
    [self.localPushDictionary removeObjectForKey:key];
    [[NSNotificationCenter defaultCenter] postNotificationName:CMApplicationDidReceiveLocalNotification
                                                        object:nil
                                                      userInfo:userInfo];
    if (self.localNotificationHandler) {
        self.localNotificationHandler(key, userInfo);
    }
    NSLog(@"self.localPushDictionary2: %@",self.localPushDictionary);
}

- (void)cancelAllLocalNotifications{
    if (@available(iOS 10.0, *)) {
        [[UNUserNotificationCenter currentNotificationCenter] removeAllPendingNotificationRequests];
    } else {
        [[UIApplication sharedApplication] cancelAllLocalNotifications];
    }
    [self.localPushDictionary removeAllObjects];
}

- (void)cancelLocalNotification:(CMLocalNotification *)localNotification{
    if (!localNotification) {
        return;
    }
    [self cancelLocalNotificationForKey:localNotification.identifier];
}

- (void)cancelLocalNotificationForKey:(NSString *)key{
    if (!self.localPushDictionary[key]) {
        return;
    }
    if (@available(iOS 10.0, *)) {
        [[UNUserNotificationCenter currentNotificationCenter] removePendingNotificationRequestsWithIdentifiers:@[key]];
    } else {
        CMLocalNotification *noti = self.localPushDictionary[key];
        if (noti.localNoti) {
           [[UIApplication sharedApplication] cancelLocalNotification:noti.localNoti];
        }
    }
    [self.localPushDictionary removeObjectForKey:key];
}

#pragma mark -
#pragma mark - Post on now

- (CMLocalNotification *)postNotificationOnNowForKey:(NSString *)key
                                           alertBody:(NSString *)alertBody{
     return [self postNotificationOnNow:YES fireDate:nil forKey:key alertBody:alertBody userInfo:nil];
}

- (CMLocalNotification *)postNotificationOnNowForKey:(NSString *)key
                          alertBody:(NSString *)alertBody
                           userInfo:(NSDictionary *)userInfo{
    return [self postNotificationOnNow:YES fireDate:nil forKey:key alertBody:alertBody userInfo:userInfo];
}

#pragma mark -
#pragma mark - Post on specified date

- (CMLocalNotification *)postNotificationOn:(NSDate *)fireDate
                    forKey:(NSString *)key
                 alertBody:(NSString *)alertBody{
    return [self postNotificationOnNow:NO fireDate:fireDate forKey:key alertBody:alertBody userInfo:nil];
}

- (CMLocalNotification *)postNotificationOn:(NSDate *)fireDate
                    forKey:(NSString *)key
                 alertBody:(NSString *)alertBody
                  userInfo:(NSDictionary *)userInfo{
    return [self postNotificationOnNow:NO fireDate:fireDate forKey:key alertBody:alertBody userInfo:userInfo];
}

- (CMLocalNotification *)postNotificationOnNow:(BOOL)presentNow
                     fireDate:(NSDate *)fireDate
                       forKey:(NSString *)key
                    alertBody:(NSString *)alertBody
                     userInfo:(NSDictionary *)userInfo{
    if (!key) {
        return nil;
    }
    
    if (self.localPushDictionary[key]) {
        [self cancelLocalNotificationForKey:key];
    }
    
    CMLocalNotification *noti = [[CMLocalNotification alloc] init];
    noti.identifier = key;
    noti.fireDate = fireDate;
    noti.alertBody = alertBody;
    noti.userInfo = userInfo;

    NSMutableDictionary *pendingInfo = [NSMutableDictionary dictionaryWithDictionary:userInfo];
    [pendingInfo setObject:key forKey:CMLocalNotificationHandlingKeyName];
    [pendingInfo setObject:key forKey:@"identifier"];
    if (alertBody) {
        [pendingInfo setObject:alertBody forKey:@"alertBody"];
    }
    if (userInfo) {
        [pendingInfo setObject:userInfo forKey:@"userInfo"];
    }
    if (fireDate) {
        [pendingInfo setObject:fireDate forKey:@"fireDate"];
    }
    if (@available(iOS 10.0, *)) {
        UNMutableNotificationContent *content = [[UNMutableNotificationContent alloc]init];
        content.body = alertBody;
        content.userInfo = pendingInfo;
        content.sound = [UNNotificationSound defaultSound];
        //添加发送通知请求
        NSTimeInterval interval = 1.0;
        if (!presentNow && [fireDate compare:[NSDate date]] != NSOrderedAscending) {
            interval = [fireDate timeIntervalSinceDate:[NSDate date]];
        }
        NSLog(@"interval-> %f",interval);
        UNTimeIntervalNotificationTrigger *trigger = [UNTimeIntervalNotificationTrigger triggerWithTimeInterval:interval repeats:NO];
        UNNotificationRequest *requset = [UNNotificationRequest requestWithIdentifier:key content:content trigger:trigger];
        [[UNUserNotificationCenter currentNotificationCenter] addNotificationRequest:requset withCompletionHandler:^(NSError * _Nullable error) {
            NSLog(@"error-> %@",error);
        }];
    } else {
        UILocalNotification *localNotification = [[UILocalNotification alloc] init];
        if (!localNotification) {
            return nil;
        }
        localNotification.userInfo = pendingInfo;
        localNotification.alertBody = alertBody;
        localNotification.soundName = UILocalNotificationDefaultSoundName;
        if (presentNow && !fireDate) {
            [[UIApplication sharedApplication] presentLocalNotificationNow:localNotification];
        } else {
            localNotification.fireDate = fireDate;
            localNotification.timeZone = [NSTimeZone defaultTimeZone];
            [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
        }
        noti.localNoti = localNotification;
    }
    [self.localPushDictionary setObject:noti forKey:key];
    return noti;
}
@end
