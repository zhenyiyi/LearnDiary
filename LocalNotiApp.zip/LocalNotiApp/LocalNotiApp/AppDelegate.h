//
//  AppDelegate.h
//  LocalNotiApp
//
//  Created by 张枫林 on 2018/11/23.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

