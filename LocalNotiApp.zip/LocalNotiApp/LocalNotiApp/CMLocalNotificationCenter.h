//
//  CMLocalNotificationImp.h
//  LocalNotiApp
//
//  Created by 张枫林 on 2018/11/23.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


extern NSString *const CMLocalNotificationHandlingKeyName;
extern NSString *const CMApplicationDidReceiveLocalNotification;

typedef void (^CMLocalNotificationHandler)(NSString *key, NSDictionary *userInfo);

@interface CMLocalNotification : NSObject 

@property (nonatomic, readonly, copy) NSString *identifier;

@property (nonatomic, readonly, copy) NSString *alertBody;

@property (nonatomic, readonly, copy) NSDictionary *userInfo;

@property (nonatomic, readonly, copy) NSDate* fireDate;

@end


@interface CMLocalNotificationCenter : NSObject

@property (nonatomic, copy) CMLocalNotificationHandler localNotificationHandler;

+ (instancetype)defaultCenter;

- (void) appRegisterlocalNotifications;

- (NSArray *)localNotifications;

//Handling For iOS8 -iOS10
- (void)didReceiveLocalNotificationUserInfo:(NSDictionary *)userInfo;

//Cancel

- (void)cancelAllLocalNotifications;

- (void)cancelLocalNotification:(CMLocalNotification *)localNotification;

- (void)cancelLocalNotificationForKey:(NSString *)key;

//Post on now

- (CMLocalNotification *)postNotificationOnNowForKey:(NSString *)key
                                           alertBody:(NSString *)alertBody;

- (CMLocalNotification *)postNotificationOnNowForKey:(NSString *)key
                                           alertBody:(NSString *)alertBody
                                            userInfo:(NSDictionary *)userInfo;

//Post on specified date

- (CMLocalNotification *)postNotificationOn:(NSDate *)fireDate
                                     forKey:(NSString *)key
                                  alertBody:(NSString *)alertBody;

- (CMLocalNotification *)postNotificationOn:(NSDate *)fireDate
                                     forKey:(NSString *)key
                                  alertBody:(NSString *)alertBody
                                   userInfo:(NSDictionary *)userInfo;



@end
