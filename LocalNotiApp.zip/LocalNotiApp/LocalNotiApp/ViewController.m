//
//  ViewController.m
//  LocalNotiApp
//
//  Created by 张枫林 on 2018/11/23.
//

#import "ViewController.h"
#import "CMLocalNotificationCenter.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

NSString * unqiueKey = @"unqiueKey";
NSString * body = @"本地通知";

- (IBAction)start:(id)sender {
    NSDate *date = [NSDate dateWithTimeIntervalSinceNow:60];
    [[CMLocalNotificationCenter defaultCenter] postNotificationOn:date forKey:unqiueKey alertBody:body];
}

- (IBAction)reset:(id)sender {
    [self start:sender];
}

- (IBAction)stop:(id)sender {
    [[CMLocalNotificationCenter defaultCenter] cancelLocalNotificationForKey:unqiueKey];
}



@end
