//
//  CMLocalNotificationImp.h
//  LocalNotiApp
//
//  Created by 张枫林 on 2018/11/23.
//

#import <Foundation/Foundation.h>
#ifdef NSFoundationVersionNumber_iOS_9_x_Max
    #import <UserNotifications/UserNotifications.h>
#endif

@interface CMLocalNotificationImp : NSObject  <UNUserNotificationCenterDelegate>

@end
