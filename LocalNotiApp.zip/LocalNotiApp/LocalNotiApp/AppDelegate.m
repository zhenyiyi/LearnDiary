//
//  AppDelegate.m
//  LocalNotiApp
//
//  Created by 张枫林 on 2018/11/23.
//

#import "AppDelegate.h"
#import "CMLocalNotificationCenter.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    [[CMLocalNotificationCenter defaultCenter] appRegisterlocalNotifications];
    
    if (launchOptions[UIApplicationLaunchOptionsLocalNotificationKey]) {
        [[CMLocalNotificationCenter defaultCenter] didReceiveLocalNotificationUserInfo:launchOptions];
    }
    
    return YES;
}

- (void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification{
    [[CMLocalNotificationCenter defaultCenter] didReceiveLocalNotificationUserInfo:notification.userInfo];
}


@end
